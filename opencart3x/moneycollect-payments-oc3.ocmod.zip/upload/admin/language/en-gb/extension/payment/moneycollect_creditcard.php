<?php

$_['text_moneycollect_creditcard'] = '<a href="https://www.moneycollect.com/" target="_blank"><img height="20px" src="https://www.moneycollect.com/static/common/img/logo/site_logo.png"></a>';

$_['heading_title'] = 'Moneycollect Credit Card';
$_['text_extension'] = 'Extensions';


