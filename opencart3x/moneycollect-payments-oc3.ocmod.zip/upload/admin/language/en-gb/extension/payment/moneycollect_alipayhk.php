<?php

$_['text_moneycollect_alipayhk'] = '<a href="https://www.moneycollect.com/" target="_blank"><img height="20px" src="https://www.moneycollect.com/static/common/img/logo/site_logo.png"></a>';

$_['heading_title'] = 'Moneycollect Alipay HK';
$_['text_extension'] = 'Extensions';


