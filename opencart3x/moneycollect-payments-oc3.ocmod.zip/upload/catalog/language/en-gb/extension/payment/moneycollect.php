<?php
$_['text_loading'] = 'Loading...';
$_['text_error'] = 'System Error! ';
$_['text_new_card'] = 'Use a new card';
$_['text_enter_card'] = 'Enter your card number';
$_['text_save_card'] = 'Save card for future purchases.';
$_['text_redirect'] = 'You will be redirected for payment processing.';

?>    